from flask import Flask, render_template, request, redirect, flash
import smtplib
from email.message import EmailMessage

app = Flask(__name__)
app.secret_key = 'c563ffe09b24b0f1cdd1f4988d8ce591'  # Replace with a strong key

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/services')
def services():
    return render_template('services.html')

@app.route('/send_inquiry', methods=['POST'])
def send_inquiry():
    name = request.form['companyName']
    email = request.form['email']
    message = request.form['message']

    try:
        # Replace with your credentials and configuration
        msg = EmailMessage()
        msg['Subject'] = 'Inquiry from RUYA Bio Fuel Website'
        msg['From'] = email
        msg['To'] = 'yourcompany@email.com'  # Replace with your receiving email
        msg.set_content(f"Name: {name}\nEmail: {email}\nMessage:\n{message}")

        # SMTP Server Config (Gmail example)
        with smtplib.SMTP_SSL('smtp.gmail.com', 465) as smtp:
            smtp.login('yourcompany@email.com', 'your_app_password')
            smtp.send_message(msg)

        flash("Thank you! Your message has been sent.", "success")
    except Exception as e:
        flash(f"Error sending message: {str(e)}", "danger")

    return redirect('/')

if __name__ == '__main__':
    app.run(debug=True)
